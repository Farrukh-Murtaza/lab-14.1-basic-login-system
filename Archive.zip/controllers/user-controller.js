
require("dotenv").config();
const User = require("../models/user-model");
const jwt = require("jsonwebtoken");

async function registerUser (req, res) {
    try {
        const foundUser = await User.findOne({email: req.body.email});

        if(foundUser != null) return res.status(400).json("this user already exists.");
        
        const newUser = await User.create(req.body);

        const payload = {_id : newUser._id };

        const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.status(201).json({ message: "User created successfully.",token});        
    } catch (error) {
        console.error(error);
        res.status(400).json({ message: error.message});
    }
};
async function loginUser (req, res) {
    try {
        const user = await User.findOne({email: req.body.email});

        if(!user){
            return res.status(400).json("Incorrect email or password.");
        }

        const correctPassword = await user.isCorrectPassword(req.body.password);

        if(!correctPassword){
            return res.status(400).json({message: "Incorrect email or password."});
        }

        const payload = {_id: user._id , username : user.username};

        const token = jwt.sign(payload,process.env.JWT_SECRET, { expiresIn: "1h" });

        res.status(200).json({message: "User Authorized", token})


    } catch (error) {
        console.error(error);
        res.status(400).json({ message: error.message});
    }
};

module.exports = {
    registerUser,
    loginUser
}